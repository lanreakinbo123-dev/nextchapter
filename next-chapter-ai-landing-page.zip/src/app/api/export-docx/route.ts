import { NextRequest, NextResponse } from "next/server";
import { createCvDocx, createDocxBuffer } from "@/lib/docx-builder";
import { CvData, CvTemplateId } from "@/lib/cv-templates";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    let buffer: Buffer;
    let baseName: string;

    if (body.cvData) {
      buffer = await createCvDocx(body.cvData as CvData, (body.template || "clean") as CvTemplateId);
      baseName = `${body.cvData.fullName || "CV"}_${body.template || "clean"}`;
    } else {
      if (!body.content) {
        return NextResponse.json({ error: "Missing document content" }, { status: 400 });
      }
      buffer = await createDocxBuffer(body.title || "Next_Chapter_Document", body.content);
      baseName = body.title || "Next_Chapter_Career_Document";
    }

    const safeFilename = baseName.replace(/[^a-zA-Z0-9_\-\s]/g, "").replace(/\s+/g, "_");

    return new NextResponse(new Uint8Array(buffer), {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "Content-Disposition": `attachment; filename="${safeFilename}.docx"`,
      },
    });
  } catch (error) {
    console.error("Export DOCX failed:", error);
    return NextResponse.json({ error: "Failed to create DOCX file" }, { status: 500 });
  }
}
