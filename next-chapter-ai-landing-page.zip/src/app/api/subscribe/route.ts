import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const { plan, fullName, email, paymentMethod } = await req.json();

    if (!plan || !fullName || !email) {
      return NextResponse.json(
        { error: "Plan, full name, and email are required" },
        { status: 400 }
      );
    }

    const amount = plan === "monthly" ? 20000 : 7000;

    let subId = 1;
    try {
      const [record] = await db
        .insert(subscriptions)
        .values({
          plan,
          amount,
          currency: "NGN",
          fullName,
          email,
          paymentMethod: paymentMethod || "paystack",
          status: "active",
        })
        .returning({ id: subscriptions.id });
      if (record) subId = record.id;
    } catch (dbErr) {
      console.warn("Could not record subscription in database:", dbErr);
    }

    return NextResponse.json({
      success: true,
      subscriptionId: subId,
      plan,
      amount,
      currency: "NGN",
      message: `Successfully subscribed to Next Chapter ${plan === "monthly" ? "Monthly Pro (₦20,000)" : "Weekly Pass (₦7,000)"}!`,
    });
  } catch (error) {
    console.error("Subscription error:", error);
    return NextResponse.json({ error: "Failed to process subscription" }, { status: 500 });
  }
}
