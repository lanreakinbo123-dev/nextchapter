import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { leads } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const { email, phone, careerInterest } = await req.json();

    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "A valid email is required" }, { status: 400 });
    }

    try {
      await db.insert(leads).values({
        email,
        phone: phone || null,
        careerInterest: careerInterest || "General Career Prep",
      });
    } catch (dbErr) {
      console.warn("Database insert lead error:", dbErr);
    }

    return NextResponse.json({
      success: true,
      message: "You're on the list! Check your inbox for the free 2025 Nigerian Youth Career Playbook & discount code.",
    });
  } catch (error) {
    console.error("Lead capture error:", error);
    return NextResponse.json({ error: "Failed to submit request" }, { status: 500 });
  }
}
