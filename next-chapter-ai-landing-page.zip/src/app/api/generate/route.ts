import { NextRequest, NextResponse } from "next/server";
import { generateCareerDocument } from "@/lib/ai-generator";
import { db } from "@/db";
import { documents } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.documentType || !body.fullName || !body.targetRole) {
      return NextResponse.json(
        { error: "Missing required fields: documentType, fullName, and targetRole are required" },
        { status: 400 }
      );
    }

    const generated = await generateCareerDocument({
      documentType: body.documentType,
      fullName: body.fullName,
      email: body.email,
      phone: body.phone,
      location: body.location,
      targetRole: body.targetRole,
      targetCompany: body.targetCompany,
      experienceLevel: body.experienceLevel,
      skills: body.skills,
      education: body.education,
      experienceDetails: body.experienceDetails,
      programOrDegree: body.programOrDegree,
      university: body.university,
      careerGoals: body.careerGoals,
      selectedProfile: body.selectedProfile,
      jobDescriptions: body.jobDescriptions,
      mode: body.mode,
      pastedCV: body.pastedCV,
      correctionNote: body.correctionNote,
    });

    let savedId: number | null = null;
    try {
      const [record] = await db
        .insert(documents)
        .values({
          documentType: body.documentType,
          fullName: body.fullName,
          email: body.email || null,
          targetRole: body.targetRole,
          targetCompany: body.targetCompany || null,
          experienceLevel: body.experienceLevel || "entry",
          content: generated.content,
          atsScore: generated.atsScore,
        })
        .returning({ id: documents.id });
      savedId = record?.id ?? null;
    } catch (dbErr) {
      console.warn("Could not persist to DB (will proceed with response):", dbErr);
    }

    return NextResponse.json({
      success: true,
      id: savedId,
      ...generated,
    });
  } catch (error) {
    console.error("API /api/generate error:", error);
    return NextResponse.json(
      { error: "Failed to generate document. Please try again." },
      { status: 500 }
    );
  }
}
